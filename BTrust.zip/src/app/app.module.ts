import { HomeComponent } from './pages/home/home.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuContentComponent } from './shared/menu-content/menu-content.component';
import { HeaderContentComponent } from './shared/header-content/header-content.component';
import { FooterContentComponent } from './shared/footer-content/footer-content.component';
import { AdminLayoutComponent } from './layout/admin-layout/admin-layout.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuContentComponent,
    HeaderContentComponent,
    FooterContentComponent,
    AdminLayoutComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
