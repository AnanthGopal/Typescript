import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminLayoutComponent } from './layout/admin-layout/admin-layout.component';
import { HomeComponent } from './pages/home/home.component';
const routes: Routes = [
    { path: '', redirectTo: '/Home', pathMatch: 'full' },
    {
      path: '',
      component: AdminLayoutComponent,
      children: [
        { path: 'Home', component: HomeComponent, pathMatch: 'full' }
      ]
    }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
